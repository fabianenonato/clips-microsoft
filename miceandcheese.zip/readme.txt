﻿=== Mouse Cursor Set ===

By: cursorer (http://www.rw-designer.com/user/11438) johannff@web.de

Download: http://www.rw-designer.com/cursor-set/miceandcheese

Author's decription:

Cursors with mice!
no resize and move.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.