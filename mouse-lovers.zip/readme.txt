﻿=== Mouse Lovers Cursor Set ===

By: Jake (http://www.rw-designer.com/user/34903) njake247@gmail.com

Download: http://www.rw-designer.com/cursor-set/mouse-lovers

Author's decription:

A collection of mouse-friendly cursors for your rodent-loving computer.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.