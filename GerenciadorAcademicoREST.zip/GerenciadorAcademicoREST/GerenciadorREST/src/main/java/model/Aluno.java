package model;

import java.io.Serializable;

public class Aluno implements Serializable{
	private static final long serialVersionUID = 1;

	private int Codigo;
	private String Nome;
	private String Email;

	public Aluno(){
		
	}
	
	public Aluno(int Codigo, String Nome, String Email){
		this.Codigo = Codigo;
		this.Nome = Nome;
		this.Email = Email;
	}
	
	public int getCodigo() {
		return Codigo;
	}

	public void setCodigo(int Codigo) {
		this.Codigo = Codigo;
	}

	public String getNome() {
		return Nome;
	}

	public void setNome(String Nome) {
		this.Nome = Nome;
	}

	public String getEmail() {
		return Email;
	}

	public void setEmail(String Email) {
		this.Email = Email;
	}
	
}
