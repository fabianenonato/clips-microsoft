package model;

import java.util.ArrayList;

public class Banco {

	private static Banco instancia;
	private ArrayList<Aluno> Alunos;
	private ArrayList<Disciplina> Disciplinas;
	private ArrayList<Nota> Notas;
	
	

	private Banco(){
		Alunos = new ArrayList<Aluno>();
		Disciplinas = new ArrayList<Disciplina>();
		Notas = new ArrayList<Nota>();
		
	}
	
	public static Banco getInstance(){
		if( instancia == null )
			instancia = new Banco();
		return instancia;
	}

	public ArrayList<Aluno> getAlunos() {
		return Alunos;
	}

	public ArrayList<Disciplina> getDisciplinas() {
		
		return Disciplinas;
	}

	public ArrayList<Nota> getNotas() {
		return Notas;
	}
}
