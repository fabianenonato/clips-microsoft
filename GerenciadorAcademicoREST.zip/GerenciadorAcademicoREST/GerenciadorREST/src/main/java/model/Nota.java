package model;

import java.io.Serializable;

public class Nota implements Serializable{
	private static final long serialVersionUID = 1;
	private int CodAluno;
	private int CodDisciplina;
	private double Nota;
	private double Freq;
	
	public Nota(int codAluno, int codDisciplina, double nota, double freq) {
		CodAluno = codAluno;
		CodDisciplina = codDisciplina;
		Nota = nota;
		Freq = freq;
	}

	public Nota(){
		
	}
	
	public int getCodAluno() {
		return CodAluno;
	}

	public void setCodAluno(int codAluno) {
		CodAluno = codAluno;
	}

	public int getCodDisciplina() {
		return CodDisciplina;
	}

	public void setCodDisciplina(int codDisciplina) {
		CodDisciplina = codDisciplina;
	}

	public double getNota() {
		return Nota;
	}

	public void setNota(double nota) {
		Nota = nota;
	}

	public double getFreq() {
		return Freq;
	}

	public void setFreq(double freq) {
		Freq = freq;
	}
	
}
