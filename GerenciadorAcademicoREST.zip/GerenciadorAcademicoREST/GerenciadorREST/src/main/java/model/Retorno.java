package model;

import java.io.Serializable;

public class Retorno implements Serializable{
	private static final long serialVersionUID = 1;

	private String tipoRetorno;
	private String mensagem;
	
	public Retorno(String tipoRetorno, String mensagem) {
		this.tipoRetorno = tipoRetorno;
		this.mensagem = mensagem;
	}
	
	public Retorno(){
		
	}

	public String getTipoRetorno() {
		return tipoRetorno;
	}

	public void setTipoRetorno(String tipoRetorno) {
		this.tipoRetorno = tipoRetorno;
	}

	public String getMensagem() {
		return mensagem;
	}

	public void setMensagem(String mensagem) {
		this.mensagem = mensagem;
	}
	
}
