package rest.config;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.servlet.ServletContextHandler;
import org.eclipse.jetty.servlet.ServletHolder;
import org.glassfish.jersey.servlet.ServletContainer;

public class ServiceApp {
	 public static void main(String[] args) throws Exception {     
    	//Porta do servidor
        Server jettyServer = new Server(8080);
        ServletContextHandler context = new ServletContextHandler(ServletContextHandler.SESSIONS);
        context.setContextPath("/");
        jettyServer.setHandler(context);
        //Caminho raiz
        ServletHolder jerseyServlet = context.addServlet(ServletContainer.class, "/*");
        jerseyServlet.setInitOrder(0);
        //Caminho dos pacotes
        jerseyServlet.setInitParameter("jersey.config.server.provider.packages", "resource");        
        //Inicializar o servidor
        try {
            jettyServer.start();
            jettyServer.join();
        } 
        catch (Exception e) {
			e.printStackTrace();
		}
        finally {
            jettyServer.destroy();
        }	
	 }
}


