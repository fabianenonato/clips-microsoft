package resource;


import java.util.ArrayList;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import model.Banco;
import model.Nota;
import model.Retorno;

@Path("nota") // Caminho (endpoint)
public class NotaResource {

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Retorno Inserir(Nota n) {
		try{
			Banco b = Banco.getInstance();
			b.getNotas().add(n);
			return new Retorno("Sucesso", "A nota registrada.");
		}catch(Exception e){
			return new Retorno("Falha", "Ocorreu um erro");
		}
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Nota> Listar(){
		Banco b = Banco.getInstance();
		return b.getNotas();
	}
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Retorno Alterar(Nota n) {
		try{
			Banco b = Banco.getInstance();
			ArrayList<Nota> Notas = b.getNotas();
			Nota nAlterada = null;
			for(int i = 0; i < Notas.size(); i++){
				if(Notas.get(i).getCodAluno() == n.getCodAluno() && Notas.get(i).getCodDisciplina() == n.getCodDisciplina()){
					nAlterada = Notas.get(i);
					nAlterada.setFreq(n.getFreq());
					nAlterada.setNota(n.getNota());
			
					return new Retorno("Sucesso","Nota alterada com sucesso!");
				}
			}
			return new Retorno("Falha", "Nota nao encontrada");

		}catch(Exception e){
			return new Retorno("Falha", "Ocorreu um erro");
		}
	}
	
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	public Retorno Deletar(Nota n) {
		try{
			Banco b = Banco.getInstance();
			ArrayList<Nota> Notas = b.getNotas();
			for(int i = 0; i < Notas.size(); i++){
				if(Notas.get(i).getCodAluno() == n.getCodAluno() && Notas.get(i).getCodDisciplina() == n.getCodDisciplina()){
					Notas.remove(i);
					return new Retorno("Sucesso","Nota removida com sucesso!");
				}
			}
			return new Retorno("Falha", "Nota n�o encontrada");
			
		}catch(Exception e){
			return new Retorno("Falha", "Ocorreu um erro");
		}
	}
	
}
