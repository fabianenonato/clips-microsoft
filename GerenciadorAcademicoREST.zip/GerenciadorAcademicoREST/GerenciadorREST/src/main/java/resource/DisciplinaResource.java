package resource;

import java.util.ArrayList;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import model.Aluno;
import model.Banco;
import model.Disciplina;
import model.Nota;
import model.Retorno;

@Path("disciplina") //Caminho (endpoint)
public class DisciplinaResource {

	@Path("lista")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Disciplina> Listar(){
		Banco b = Banco.getInstance();
		return b.getDisciplinas();
	}
	@Path("inserir")
	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Retorno Inserir(Disciplina d) {
		//Disciplina d = new Disciplina;
	//	d.setCodigo(1);
	//	d.setNome("teste");
	//	Disciplinas.add(2, d);
		try{
			Banco b = Banco.getInstance();
			b.getDisciplinas().add(d);
			return new Retorno("Sucesso", "A Disciplina Cod: " + d.getCodigo() + ", Nome: " + d.getNome() + ", foi registrada.");
		}catch(Exception e){
			return new Retorno("Falha", "Ocorreu um erro");
		}
	}
	
	
	@Path("Boletim")
	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<String> Boletim(){
		Banco b = Banco.getInstance();
		ArrayList<Disciplina> Disciplinas = b.getDisciplinas();
		ArrayList<Aluno> Alunos = b.getAlunos();
		ArrayList<Nota> Notas = b.getNotas();
		ArrayList<String> Boletim = new ArrayList<String>();
		
		for(int i = 0; i < Alunos.size(); i++){
			for(int j = 0; j < Notas.size(); j++){
				for(int k = 0; k < Disciplinas.size(); k++){
					if(Notas.get(j).getCodDisciplina() == Disciplinas.get(k).getCodigo() && Notas.get(j).getCodAluno() == Alunos.get(i).getCodigo()){
						String linha = "Aluno: " + Alunos.get(i).getNome() + ", Disciplina: " +  Disciplinas.get(k).getNome() + ", Nota: " + Notas.get(j).getNota() + ", Freq: " + Notas.get(j).getFreq();
						Boletim.add(linha);
					}		
				}
			}
		}
		
		return Boletim;
	}
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Retorno Alterar(Disciplina d) {
		try{
			Banco b = Banco.getInstance();
			ArrayList<Disciplina> Disciplinas = b.getDisciplinas();
			Disciplina dAlterada = null;
			for(int i = 0; i < Disciplinas.size(); i++){
				if(Disciplinas.get(i).getCodigo() == d.getCodigo()){
					dAlterada = Disciplinas.get(i);
					dAlterada.setNome(d.getNome());	
					return new Retorno("Sucesso","Disciplina " + d.getCodigo() + " alterada com sucesso!");
				}
			}
			return new Retorno("Falha", "Disciplina n�o encontrada");
			
		}catch(Exception e){
			return new Retorno("Falha", "Ocorreu um erro");
		}
	}
	
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	public Retorno Deletar(Disciplina d) {
		try{
			Banco b = Banco.getInstance();
			ArrayList<Disciplina> Disciplinas = b.getDisciplinas();
			for(int i = 0; i < Disciplinas.size(); i++){
				if(Disciplinas.get(i).getCodigo() == d.getCodigo()){
					Disciplinas.remove(i);
					return new Retorno("Sucesso","Disciplina " + d.getCodigo() + " removida com sucesso!");
				}
			}
			return new Retorno("Falha", "Disciplina n�o encontrada");
			
		}catch(Exception e){
			return new Retorno("Falha", "Ocorreu um erro");
		}
	}
	
}
