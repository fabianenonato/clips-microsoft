package resource;

import java.util.ArrayList;

import javax.ws.rs.*;
import javax.ws.rs.core.MediaType;

import model.Aluno;
import model.Banco;
import model.Retorno;

@Path("aluno") // Caminho (endpoint)
public class AlunoResource {

	@POST
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Retorno Inserir(Aluno a) {
		try{
			Banco b = Banco.getInstance();
			b.getAlunos().add(a);
			return new Retorno("Sucesso", "O aluno Cod: " + a.getCodigo() + ", Nome: " + a.getNome() + ", foi registrado");
		}catch(Exception e){
			return new Retorno("Falha", "Ocorreu um erro");
		}
	}

	@GET
	@Produces(MediaType.APPLICATION_JSON)
	public ArrayList<Aluno> Listar(){
		Banco b = Banco.getInstance();
		return b.getAlunos();
	}
	
	@PUT
	@Consumes(MediaType.APPLICATION_JSON)
	@Produces(MediaType.APPLICATION_JSON)
	public Retorno Alterar(Aluno a) {
		try{
			Banco b = Banco.getInstance();
			ArrayList<Aluno> Alunos = b.getAlunos();
			Aluno modificado = null;
			for(int i = 0; i < Alunos.size(); i++){
				if(Alunos.get(i).getCodigo() == a.getCodigo()){
					modificado = Alunos.get(i);
					modificado.setEmail(a.getEmail());
					modificado.setNome(a.getNome());
					return new Retorno("Sucesso", "O aluno Cod: " + a.getCodigo() + " foi alterado com sucesso!");
				}
			}
			return new Retorno("Falha", "Aluno nao encontrado");
			
		}catch(Exception e){
			return new Retorno("Falha", "Ocorreu um erro");
		}
	}
	
	@DELETE
	@Produces(MediaType.APPLICATION_JSON)
	public Retorno Deletar(Aluno a) {
		try{
			Banco b = Banco.getInstance();
			ArrayList<Aluno> Alunos = b.getAlunos();
			for(int i = 0; i < Alunos.size(); i++){
				if(Alunos.get(i).getCodigo() == a.getCodigo()){
					Alunos.remove(i);
					return new Retorno("Sucesso", "O aluno Cod: " + a.getCodigo() + " foi removido!");
				}
			}
			return new Retorno("Falha", "Aluno nao encontrado");
		}catch(Exception e){
			return new Retorno("Falha", "Ocorreu um erro");
		}
	}
}
