﻿=== Snake Cursor Set ===

By: adrenochromedream (http://www.rw-designer.com/user/68859) grrrlx@excite.com

Download: http://www.rw-designer.com/cursor-set/snakes

Author's description:

Snake cursors

==========

License: Custom

You are free:

* To Use the work for personal noncommercial purposes.

For any other use, you must contact the author and ask for permission.