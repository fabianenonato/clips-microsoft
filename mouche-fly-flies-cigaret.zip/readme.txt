﻿=== DirtyMiniKit Cursor Set ===

By: Bulut (http://www.rw-designer.com/user/34026) bulutpn@orange.fr

Download: http://www.rw-designer.com/cursor-set/mouche-fly-flies-cigaret

Author's decription:

A dirty Mini Kit...
Flies are realists, their wings are transparent.
I hope that you appreciate.

Un mini kit crado.
Les mouches sont réalistes, leurs ailes sont transparentes.

==========

License: Released to Public Domain

You are free:

* To use this work for any legal purpose.